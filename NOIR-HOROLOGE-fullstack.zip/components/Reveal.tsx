'use client';
import {useLayoutEffect,useRef} from 'react';
import gsap from 'gsap';
import {ScrollTrigger} from 'gsap/ScrollTrigger';
gsap.registerPlugin(ScrollTrigger);
export default function Reveal(){const ref=useRef<HTMLDivElement>(null);useLayoutEffect(()=>{const ctx=gsap.context(()=>{gsap.utils.toArray<HTMLElement>('.reveal').forEach((el)=>gsap.fromTo(el,{y:55,opacity:0},{y:0,opacity:1,duration:1,ease:'power3.out',scrollTrigger:{trigger:el,start:'top 82%',once:true}}));gsap.utils.toArray<HTMLElement>('.parallax').forEach((el)=>gsap.to(el,{yPercent:-8,ease:'none',scrollTrigger:{trigger:el,start:'top bottom',end:'bottom top',scrub:true}}));},ref);return()=>ctx.revert()},[]);return <div ref={ref} aria-hidden="true"/>}
