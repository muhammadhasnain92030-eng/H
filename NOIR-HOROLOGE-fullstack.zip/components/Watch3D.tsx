'use client';
import { Canvas, useFrame } from '@react-three/fiber';
import { ContactShadows, Environment, Float, OrbitControls, RoundedBox, Torus } from '@react-three/drei';
import { useRef } from 'react';
import * as THREE from 'three';
function Watch(){const g=useRef<THREE.Group>(null); useFrame((_,d)=>{if(g.current){g.current.rotation.y+=d*.16;g.current.rotation.x=Math.sin(Date.now()*.00035)*.08}}); return <group ref={g} rotation={[.18,-.35,.05]} scale={1.45}>
 <RoundedBox args={[2.25,.38,2.55]} radius={.18} smoothness={5}><meshStandardMaterial color="#151515" metalness={.92} roughness={.2}/></RoundedBox>
 <Torus args={[1.02,.11,32,96]} rotation={[Math.PI/2,0,0]} position={[0,.25,0]}><meshStandardMaterial color="#c8a96b" metalness={1} roughness={.16}/></Torus>
 <mesh position={[0,.29,0]} rotation={[Math.PI/2,0,0]}><cylinderGeometry args={[.91,.91,.08,64]}/><meshStandardMaterial color="#080808" metalness={.35} roughness={.2}/></mesh>
 <mesh position={[0,.36,0]} rotation={[Math.PI/2,0,0]}><cylinderGeometry args={[.86,.86,.035,64]}/><meshStandardMaterial color="#191919" metalness={.1} roughness={.4}/></mesh>
 {[0,45,90,135,180,225,270,315].map(a=>{const r=a*Math.PI/180;return <mesh key={a} position={[Math.sin(r)*.67,.405,Math.cos(r)*.67]} rotation={[0,0,0]}><boxGeometry args={[a%90===0?.045:.025,.025,a%90===0?.15:.08]}/><meshStandardMaterial color="#e8d7b0" metalness={.7}/></mesh>})}
 <mesh position={[0,.45,0]} rotation={[0,0,0]}><boxGeometry args={[.025,.025,1.18]}/><meshStandardMaterial color="#e8d7b0"/></mesh><mesh position={[0,.46,0]} rotation={[0,Math.PI/2,0]}><boxGeometry args={[.025,.025,.86]}/><meshStandardMaterial color="#e8d7b0"/></mesh>
 <mesh position={[0,-.05,0]} rotation={[Math.PI/2,0,0]}><cylinderGeometry args={[.08,.08,.04,32]}/><meshStandardMaterial color="#e8d7b0" metalness={1}/></mesh>
 <mesh position={[0,-1.42,0]}><boxGeometry args={[1.18,.3,.24]}/><meshStandardMaterial color="#090909" metalness={.6} roughness={.28}/></mesh><mesh position={[0,1.42,0]}><boxGeometry args={[1.18,.3,.24]}/><meshStandardMaterial color="#090909" metalness={.6} roughness={.28}/></mesh>
 </group>}
export default function Watch3D(){return <Canvas camera={{position:[0,0,5.5],fov:35}} dpr={[1,2]}><ambientLight intensity={1.1}/><directionalLight position={[4,5,4]} intensity={3}/><pointLight position={[-4,2,3]} intensity={2}/><Float speed={1.1} rotationIntensity={.2} floatIntensity={.25}><Watch/></Float><ContactShadows position={[0,-1.8,0]} opacity={.35} scale={5} blur={2.5} far={4}/><Environment preset="studio"/><OrbitControls enablePan={false} minDistance={4} maxDistance={7} autoRotate={false}/></Canvas>}
