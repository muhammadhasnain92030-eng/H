# NOIR HOROLOGE
Premium full-stack watch storefront built with Next.js, Prisma/SQLite, React Three Fiber and GSAP-ready architecture.

## Run locally
1. `npm install`
2. `cp .env.example .env`
3. `npx prisma generate`
4. `npm run db:push`
5. `npm run db:seed`
6. `npm run build`
7. `npm run dev`

Open http://localhost:3000

## Included
- Cinematic full-screen hero
- Procedural 3D watch with orbit controls
- Responsive premium UI, grain, marquee and hover motion
- Collections + product detail pages
- Prisma/SQLite products, orders and newsletter subscribers
- COD checkout API
- Seed database
- Mobile responsive layouts
- No secrets committed

## Production upgrades
Connect a hosted Postgres/Supabase database, image storage, authentication/admin, payment gateway and real shipping provider by replacing the local adapters/API endpoints.
