import './globals.css';
export const metadata={title:'NOIR HOROLOGE — Modern Timepieces',description:'A cinematic premium watch house.'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body className="grain">{children}</body></html>}
