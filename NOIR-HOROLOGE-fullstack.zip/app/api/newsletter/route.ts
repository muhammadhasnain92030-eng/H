import { NextResponse } from 'next/server'; import { db } from '@/lib/db';
export async function POST(req:Request){const {email}=await req.json(); if(!email||!/^\S+@\S+\.\S+$/.test(email)) return NextResponse.json({error:'Valid email required.'},{status:400}); await db.subscriber.upsert({where:{email},update:{},create:{email}}); return NextResponse.json({ok:true})}
